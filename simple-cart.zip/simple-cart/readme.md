# Shopping Cart

# [Preview the site](https://alsiam.github.io/web-projects/shopping-cart)

![image info](../assets/images/shopping-cart.png)