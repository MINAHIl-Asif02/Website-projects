# Calculator

# [Preview the site](https://alsiam.github.io/web-projects/calculator)

![image info](../assets/images/calculator.png)