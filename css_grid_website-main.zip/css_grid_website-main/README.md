<h2> Website 📰</h2>
  <p> Mainly using CSS Grid System</p>
  
  <h3> Front view of Website  / Home page 📄</h3>
  
![image](https://user-images.githubusercontent.com/69325431/123464439-6bb56880-d60a-11eb-8072-b7fee929d322.png)
<hr>


<h3> Footer of Website</h3>


![image](https://user-images.githubusercontent.com/69325431/123464809-f0a08200-d60a-11eb-9d70-0e7f3d636397.png)
<hr>


<h3> About page 📄 </h3>


![image](https://user-images.githubusercontent.com/69325431/123465950-5f320f80-d60c-11eb-8e39-0477c82010ea.png)


<hr>

<h3> Article page 📄 </h3>



![image](https://user-images.githubusercontent.com/69325431/123466093-8ee11780-d60c-11eb-812d-c2c8b70429b9.png)
