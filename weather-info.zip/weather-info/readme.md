# Weather Info

# [Preview the site](https://alsiam.github.io/web-projects/weather-info)

![image info](../assets/images/weather-info.png)